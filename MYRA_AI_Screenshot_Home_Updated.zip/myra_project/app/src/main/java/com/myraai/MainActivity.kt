package com.myraai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var answer: TextView
    private lateinit var input: EditText
    private lateinit var key: EditText
    private val prefs by lazy { getSharedPreferences("myra", MODE_PRIVATE) }
    private val http = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input.setText(it); ask(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); window.statusBarColor=Color.rgb(5,7,15); window.navigationBarColor=Color.rgb(5,7,15)
        tts=TextToSpeech(this,this); buildUI()
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.RECORD_AUDIO)
        if(android.os.Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun bg(color:Int,stroke:Int=0):GradientDrawable=GradientDrawable().apply{cornerRadius=dp(20).toFloat();setColor(color);if(stroke!=0)setStroke(dp(1),stroke)}
    private fun label(s:String,size:Float,color:Int=Color.WHITE)=TextView(this).apply{text=s;textSize=size;setTextColor(color)}
    private fun buildUI(){
        val root=LinearLayout(this).apply{orientation=1;setPadding(dp(14),dp(8),dp(14),dp(12));background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(1,2,12),Color.rgb(12,3,25),Color.rgb(1,8,20)))}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        top.addView(button("☰",Color.rgb(18,8,38)){toast("MYRA Menu")},LinearLayout.LayoutParams(dp(52),dp(48)))
        top.addView(button("👑 Premium",Color.rgb(35,18,45)){toast("MYRA Premium — coming soon")},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(button("⚙",Color.rgb(18,8,38)){settings()},LinearLayout.LayoutParams(dp(48),dp(48)))
        top.addView(button("♟",Color.rgb(35,8,38)){toast("Notifications")},LinearLayout.LayoutParams(dp(48),dp(48)))
        root.addView(top)
        root.addView(label("MYRA AI",34f,Color.rgb(220,225,255)).apply{gravity=Gravity.CENTER;typeface=Typeface.create("sans-serif-black",Typeface.BOLD);setPadding(0,dp(8),0,0)})
        root.addView(label("━━━━━━  Your Smart AI Assistant  ━━━━━━",14f,Color.rgb(80,210,255)).apply{gravity=Gravity.CENTER;setPadding(0,0,0,dp(6))})
        val orb=OrbView(this);root.addView(orb,LinearLayout.LayoutParams(-1,dp(255)))
        root.addView(label("MYRA",28f,Color.rgb(225,80,255)).apply{gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD})
        answer=label("Hello Boss…\\nI am listening…",15f,Color.WHITE).apply{gravity=Gravity.CENTER_VERTICAL;background=bg(Color.rgb(4,8,25),Color.rgb(80,30,220));setPadding(dp(18));text="🎙     Hello Boss…\\n          I am listening…"}
        root.addView(answer,LinearLayout.LayoutParams(-1,dp(82)))
        input=EditText(this).apply{hint="MYRA ko message likho…";setHintTextColor(Color.GRAY);setTextColor(Color.WHITE);textSize=14f;background=bg(Color.rgb(12,12,30),Color.rgb(50,65,150));setPadding(dp(14))}
        val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        row.addView(input,LinearLayout.LayoutParams(0,dp(48),1f));row.addView(button("🎙",Color.rgb(45,8,100)){listen()});row.addView(button("➤",Color.rgb(35,15,100)){ask(input.text.toString())})
        root.addView(row)
        val grid=GridLayout(this).apply{columnCount=4}
        val modules=listOf("💬\\nAI Chat" to {input.requestFocus()},"🎙\\nVoice\\nAssistant" to {listen()},"📷\\nLive Vision" to {vision()},"▣\\nPhone\\nControl" to {accessibility()},"♧\\nMemory" to {memory()},"🌐\\nWeb Search" to {webSearch()},"⚡\\nAutomation" to {automation()},"▦\\nMore Tools" to {toast("More Tools")})
        modules.forEach{(name,action)->val b=button(name,Color.rgb(10,8,28),action).apply{textSize=11f;background=bg(Color.rgb(8,8,25),Color.rgb(105,35,220));typeface=Typeface.DEFAULT_BOLD};val lp=GridLayout.LayoutParams().apply{width=0;height=dp(82);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(3),dp(5),dp(3),dp(5))};grid.addView(b,lp)}
        root.addView(grid)
        val status=LinearLayout(this).apply{gravity=Gravity.CENTER;orientation=0}
        status.addView(button("🔋 Battery\\n92% • Charging OK",Color.rgb(5,25,20)){toast("Battery status")},LinearLayout.LayoutParams(0,dp(72),1f))
        status.addView(button("🛡 Security\\nActive • All Safe",Color.rgb(5,18,30)){toast("Security status")},LinearLayout.LayoutParams(0,dp(72),1f))
        root.addView(status)
        root.addView(button("⌂  Home       ▥  Tasks       ☑  History       ♛  Pro",Color.rgb(15,5,35)){toast("MYRA Navigation")},LinearLayout.LayoutParams(-1,dp(58)))
        setContentView(ScrollView(this).apply{isFillViewport=true;addView(root)})
    }
    private fun button(s:String,c:Int,action:()->Unit)=Button(this).apply{text=s;textSize=12f;setTextColor(Color.WHITE);background=bg(c);isAllCaps=false;setOnClickListener{action()};minimumHeight=dp(44);setPadding(dp(8),0,dp(8),0)}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun listen(){val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");putExtra(RecognizerIntent.EXTRA_PROMPT,"MYRA se boliye")};try{speech.launch(i)}catch(_:Exception){toast("Speech recognition unavailable")}}
    private fun ask(q:String){if(q.isBlank())return;answer.text="MYRA soch rahi hai…";val k=prefs.getString("api_key","").orEmpty();if(k.isBlank()){answer.text="Settings ⚙ me Gemini API key save karein.";return}
        scope.launch{val a=withContext(Dispatchers.IO){try{val body=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",q)))));val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$k").post(body.toString().toRequestBody("application/json".toMediaType())).build();http.newCall(req).execute().use{r->val raw=r.body?.string().orEmpty();if(!r.isSuccessful)"Gemini error ${r.code}: ${raw.take(180)}" else JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")}}catch(e:Exception){"Network error: ${e.localizedMessage}"}}
            answer.text=a;tts.speak(a,TextToSpeech.QUEUE_FLUSH,null,"reply");prefs.edit().putString("history",(prefs.getString("history","").orEmpty()+"\nYou: $q\nMYRA: $a").takeLast(15000)).apply();speakEleven(q,a)}
    }
    private fun speakEleven(q:String,a:String){val url=prefs.getString("worker_url","").orEmpty();val voice=prefs.getString("voice_id","").orEmpty();if(url.isBlank()||voice.isBlank())return
        scope.launch(Dispatchers.IO){try{val body=JSONObject().put("text",a).put("voiceId",voice).toString().toRequestBody("application/json".toMediaType());http.newCall(Request.Builder().url(url.trimEnd('/')+"/tts").post(body).build()).execute().close()}catch(_:Exception){}}
    private fun settings(){val box=LinearLayout(this).apply{orientation=1;setPadding(dp(16),dp(8),dp(16),0)}
        key=EditText(this).apply{hint="Gemini API key";setText(prefs.getString("api_key",""));setSingleLine()}
        val worker=EditText(this).apply{hint="Cloudflare Worker URL /tts base";setText(prefs.getString("worker_url",""));setSingleLine()}
        val voice=EditText(this).apply{hint="ElevenLabs Voice ID";setText(prefs.getString("voice_id",""));setSingleLine()}
        box.addView(key);box.addView(worker);box.addView(voice)
        AlertDialog.Builder(this).setTitle("MYRA Settings").setView(box).setPositiveButton("Save"){_,_->prefs.edit().putString("api_key",key.text.toString().trim()).putString("worker_url",worker.text.toString().trim()).putString("voice_id",voice.text.toString().trim()).apply();toast("Settings saved on phone")}.setNeutralButton("Accessibility"){_,_->accessibility()}.setNegativeButton("Cancel",null).show()}
    private fun accessibility(){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));toast("Accessibility settings me MYRA enable karein")}
    private fun memory(){val e=EditText(this).apply{hint="MYRA ki memory / notes";setText(prefs.getString("memory",""))};AlertDialog.Builder(this).setTitle("MYRA Memory").setView(e).setPositiveButton("Save"){_,_->prefs.edit().putString("memory",e.text.toString()).apply();toast("Memory saved")}.setNegativeButton("Cancel",null).show()}
    private fun webSearch(){val q=input.text.toString().trim();if(q.isBlank()){toast("Pehle search/message likhein");return};startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q))) )}
    private fun vision(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){permission.launch(Manifest.permission.CAMERA);return};toast("Live Vision module: camera pipeline is not yet connected")}
    private fun automation(){AlertDialog.Builder(this).setTitle("MYRA Automation").setMessage("Safe automation preview. Phone actions require Accessibility permission and explicit confirmation.").setPositiveButton("Enable Screen Control"){_,_->accessibility()}.setNegativeButton("Close",null).show()}
    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts.language=Locale("hi","IN")}
    override fun onDestroy(){scope.cancel();if(::tts.isInitialized)tts.shutdown();super.onDestroy()}
    private class OrbView(ctx:android.content.Context):View(ctx){private val paint=Paint(3);private var angle=0f;private val handler=android.os.Handler(android.os.Looper.getMainLooper());private val tick=object:Runnable{override fun run(){angle=(angle+2)%360;invalidate();handler.postDelayed(this,35)}}
        init{handler.post(tick)}
        override fun onDraw(c:Canvas){super.onDraw(c);val cx=width/2f;val cy=height/2f;val r=height*.30f
            paint.shader=RadialGradient(cx,cy,r*1.6f,intArrayOf(Color.argb(100,0,220,255),Color.argb(35,150,0,255),Color.TRANSPARENT),null,Shader.TileMode.CLAMP);c.drawCircle(cx,cy,r*1.65f,paint);paint.shader=null
            paint.style=Paint.Style.STROKE;paint.strokeWidth=dp(2).toFloat();paint.color=Color.rgb(0,235,255);c.drawCircle(cx,cy,r,paint);paint.color=Color.rgb(160,40,255);paint.strokeWidth=dp(3).toFloat();c.drawArc(cx-r*1.18f,cy-r*1.18f,cx+r*1.18f,cy+r*1.18f,angle,210,false,paint)
            paint.style=Paint.Style.FILL;paint.shader=RadialGradient(cx-r*.25f,cy-r*.35f,r*1.5f,intArrayOf(Color.rgb(65,170,255),Color.rgb(20,25,90),Color.rgb(3,5,18)),null,Shader.TileMode.CLAMP);c.drawCircle(cx,cy,r*.88f,paint);paint.shader=null
            paint.color=Color.argb(170,80,230,255);paint.strokeWidth=dp(2).toFloat();paint.style=Paint.Style.STROKE;for(i in 0..4){val rr=r*(1.3f+i*.12f);c.drawArc(cx-rr,cy-rr,cx+rr,cy+rr,angle+i*35,45,false,paint)};paint.style=Paint.Style.FILL}
        override fun onDetachedFromWindow(){handler.removeCallbacks(tick);super.onDetachedFromWindow()}
    }
}
